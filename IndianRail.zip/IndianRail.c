#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>

struct station {
  int o_p;
  int i_p;
  pthread_mutex_t lock;
  pthread_cond_t train_arrived;
  pthread_cond_t passengers_seated;
  pthread_cond_t train_is_full;
};

void station_init(struct station *station);

void station_load_train(struct station *station, int count);

void station_wait_for_train(struct station *station);

void station_on_board(struct station *station);

volatile int thread_completed = 0;

void *passenger_thread(void *arg)
{
	struct station *station = (struct station*)arg;
	station_wait_for_train(station);
	__sync_add_and_fetch(&thread_completed, 1);
	return NULL;
}

struct load_train_args {
	struct station *station;
	int available_seats;
};

volatile int load_train_returned = 0;

void *load_train_thread(void *args)
{
	struct load_train_args *ltargs = (struct load_train_args*)args;
	station_load_train(ltargs->station, ltargs->available_seats);
	load_train_returned = 1;
	return NULL;
}

const char* alarm_error;
int alarm_timeout;

void _alarm(int seconds, const char *error_str)
{
	alarm_timeout = seconds;
	alarm_error = error_str;
	alarm(seconds);
}

void alarm_handler(int foo)
{
	fprintf(stderr, "Error: Failed to complete after %d seconds. Something's "
		"wrong, or your system is terribly slow. Possible error hint: [%s]\n",
		alarm_timeout, alarm_error);
	exit(1);
}

#ifndef MIN
#define MIN(x,y) ((x) < (y)) ? (x) : (y)
#endif

int main()
{
	struct station station;
	station_init(&station);

	srandom(getpid() ^ time(NULL));

	signal(SIGALRM, alarm_handler);

	_alarm(1, "station_load_train() did not return immediately when no waiting passengers");
	station_load_train(&station, 0);
	station_load_train(&station, 10);
	_alarm(0, NULL);

	int i;
	const int t_p = 100;
	int passengers_left = t_p;
	printf("\n*********** WELCOME TO LUDHIANA STATION **********\n\n");
	printf("\nTotal passengers are 100 on the station who are waiting for train.\n\n");
	for (i = 0; i < t_p; i++) {
		pthread_t tid;
		int ret = pthread_create(&tid, NULL, passenger_thread, &station);
		if (ret != 0) {
			
			perror("pthread_create");
			exit(1);
		}
	}
	
	_alarm(2, "station_load_train() did not return immediately when no free seats");
	station_load_train(&station, 0);
	_alarm(0, NULL);

	int t_p_boarded = 0;
	const int max_available_seats_per_train = 50;
	int pass = 0;
	while (passengers_left > 0) {
		_alarm(2, "Some more complicated issue appears to have caused passengers "
			"not to board when given the opportunity");

		int available_seats = random() % max_available_seats_per_train;

		printf("Train arriving Ludhiana station with %d free seats.\n", available_seats);
		load_train_returned = 0;
		struct load_train_args args = { &station, available_seats };
		pthread_t lt_tid;
		int ret = pthread_create(&lt_tid, NULL, load_train_thread, &args);
		if (ret != 0) {
			perror("pthread_create");
			exit(1);
		}

		int pass_to_reap = MIN(passengers_left, available_seats);
		int pass_reaped = 0;
		while (pass_reaped < pass_to_reap) {
			if (load_train_returned) {
				fprintf(stderr, "Error: station_load_train returned early!\n");
				exit(1);
			}
			if (thread_completed > 0) {
				if ((pass % 2) == 0)
					usleep(random() % 2);
				pass_reaped++;
				station_on_board(&station);
				__sync_sub_and_fetch(&thread_completed, 1);
			}
		}

		for (i = 0; i < 1000; i++) {
			if (i > 50 && load_train_returned)
				break;
			usleep(1000);
		}

		if (!load_train_returned) {
			fprintf(stderr, "Error: station_load_train failed to return\n");
			exit(1);
		}
		
		while (thread_completed > 0) {
			pass_reaped++;
			__sync_sub_and_fetch(&thread_completed, 1);
		}

		passengers_left -= pass_reaped;
		t_p_boarded += pass_reaped;
		printf("Train departed station with %d new passengers and expected passengers are %d. %s\n\n",pass_to_reap, pass_reaped,
			(pass_to_reap != pass_reaped) ? " *****" : "");

		if (pass_to_reap != pass_reaped) {
			fprintf(stderr, "Error: Too many passengers on this train!\n");
			exit(1);
		}

		pass++;
	}

	if (t_p_boarded == t_p) {
		printf("There is no passenger left on the station...!!!\n");
		return 0;
	} else {
		fprintf(stderr, "Error: expected %d total boarded passengers, but got %d!\n",
			t_p, t_p_boarded);
		return 1;
	}
}

void station_init(struct station *station)
{
  station->o_p = 0;
  station->i_p = 0;
  pthread_mutex_init(&(station->lock), NULL);
  pthread_cond_init(&(station->train_arrived), NULL);
  pthread_cond_init(&(station->passengers_seated), NULL);
  pthread_cond_init(&(station->train_is_full), NULL);
}

void station_load_train(struct station *station, int count)
{
  
  pthread_mutex_lock(&(station->lock));

  while ((station->o_p > 0) && (count > 0)){
    pthread_cond_signal(&(station->train_arrived));
  	count--;
  	pthread_cond_wait(&(station->passengers_seated), &(station->lock));
  }

  if (station->i_p > 0)
  	pthread_cond_wait(&(station->train_is_full), &(station->lock));

  pthread_mutex_unlock(&(station->lock));
}

void station_wait_for_train(struct station *station)
{
  pthread_mutex_lock(&(station->lock));

  station->o_p++;
  pthread_cond_wait(&(station->train_arrived), &(station->lock));
  station->o_p--;
  station->i_p++;

  pthread_mutex_unlock(&(station->lock));

  pthread_cond_signal(&(station->passengers_seated));
}

void station_on_board(struct station *station)
{
  pthread_mutex_lock(&(station->lock));

  station->i_p--;

  pthread_mutex_unlock(&(station->lock));

  if (station->i_p == 0)
  	pthread_cond_broadcast(&(station->train_is_full));
}
